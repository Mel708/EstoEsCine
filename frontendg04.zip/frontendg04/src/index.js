import React from "react";
import ReactDom from "react-dom/client"
import { BrowserRouter as Router, Routes,Route} from "react-router-dom";
import "./css/bootstrap.min.css"
import {Menu } from "./components/Header";
import {ListaPeliculas} from "./components/ListaPeliculas"
import { Login } from "./components/Login";
const root= ReactDom.createRoot(document.getElementById("root"))
root.render(<>
<Router>
    <Menu/>
    <div className="container">
        <div className="row my-5">
            <Routes>
                <Route path="/" element={<ListaPeliculas/>}></Route>
                <Route path="/login" element={<Login/>}></Route>
            </Routes>
   </div>
    </div>
</Router>
</>
)
