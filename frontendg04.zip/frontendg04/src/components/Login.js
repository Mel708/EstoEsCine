import swal from "sweetalert"
import { useRef } from "react"
export function Login (){
    const correoRef=useRef()
    const handleChange =(ev)=>{console.log(ev.target.value)}
    const handleSubmit=(ev)=>{
        ev.preventDefault()
        console.log("enviando datos...")
        const correo = correoRef.current.value
        console.log("correo..."+ correo)
        if(correo === "admin@correo.com")
        swal({
            title:"Acceso",
            text:"Acceso concedido",
            icon:"success"
    })
        else
            swal("Datos de acceso son incorrectos")
    }
return <div class="container-fluid">
<div class="row">
<div class="col-md-4 offset -4">
<form onSubmit={handleSubmit}>
    <div class="form-group">
    <label for="exampleInputEmail1">
        Correo electrónico
    </label>
    <input type="email" ref={correoRef} class="form-control" id="exampleInputEmail1" onClick= {function(){console.log('email click!')}}onChange={handleChange}/>  
    </div>
    <div class="form-group">
    <label for="exampleInputPassword1">
        Contraseña
    </label>
    <input type="password" class="form-control" id="exampleInputPassword1"/>  
    </div>
    <div class="form-group my-4">
        <button type="button" class="btn btn-primary" onClick= {handleSubmit}>
            Entrar</button>
    </div>
    </form>
</div>
</div>
</div> 
}