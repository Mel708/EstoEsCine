const generoModel = require ('../models/generosSchema')


const generoListar = async (req,res) => {
    let generos = await generoModel.find()
    res.send(generos);
}
const generosActualizar = async (req,res) =>{
    console.log(req.body)
    try {
        const {id, nombre} = req.body
        
        if (id == ''){
            res.status(400).send("id de Item No Valido")
        }

        if (nombre == '') {
            res.status(400).send("Titulo de genero No Valido")
        }else {
            //res.send("ok")
            const genero = {}

            const rta = await generosModel.updateOne(
                { _id : id},
                { $set : genero},
                { new : true}
            )
            res.status(200).json({"msj": "Genero Actualizado"})
            
        }
    } 
    catch (err) {
        console.log("Error generosActualizar: " + err)
    }
}

//delete
const generosEliminar =  async(req,res) =>{
    const id = req.params.id
    try {
        if (id == '') {
            res.satatus(400).send("el id No es valido")
        }else{
            const rta = await itemsModel.deleteOne({ _id : id})
            res.status(200).send("Genero eliminado con exito")
            console.log("eliminadod: " + id)
        }
        
    } catch (err) {
        console.log("error generosEliminar: " + err)
    }
}

module.exports ={
    generoListar,
    generosActualizar,
    generosEliminar
}