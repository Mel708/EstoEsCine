const c= require ("colors")//para cargar colores al texto

console.log("Esto es Cine")
console.log("Proyecto de misiontic2022")
console.log("G04 future")
