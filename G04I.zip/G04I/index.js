const express =require ("express")
const app = express()
const puerto=3000

//prueba el controlador
const items =require("./controllers/itemsCtrl")
console.log(items.itemsListar())


app.get("/",(req,res)=>{
    res.send("Esto es Cine")
})
//app.get("/about",(req,res)=>{
   // res.send("Pagina arerca de...")
//})
//rutas
app.use(express.json());
app.use("/about", require("./routes/paginas"))
app.use("/api", require("./routes/api"))
app.use("/api/items", require("./routes/items"))
app.listen(puerto,()=>{
    console.log("Servidor activo, puerto: "+puerto)
})
