const http= require("http")
const puerto= 3000

const fs = require("fs")// fileSystem
function getText(url){console.log("ejecutando promesa")
return new Promise(function (resolve,reject){
    fs.readFile(url,"utf-8", (err,data)=>{
if (err){
    reject(err)
}
console.log("...")
resolve(data)
    })
})
}

http.createServer((req,res)=>{
    console.log(req.url)
    if(req.url =="/registro"){
         //res.write("Página de registro")
        const arch= fs.readFileSync("registro.html","utf-8")
        getText("registro.html")
        .then((result)=>{
            console.log(result)
            res.write(result)
            return res.end()
        })
        .then(arch=>res.write(arch))
        .catch((error)=> console.log(error))
    }
    res.write("Este es un 404 - no encontrado")
    res.end()
}).listen(puerto)
console.log("servidor activo: "+puerto)
