const itemsListar=()=>{
    let listado={
        "1":"Terminator 2",
        "2":"Avatar",
        "3":"Los Vengadores",
        "4":"Monsters Inc.",
    }
    return listado
}

const itemsGuarda=(req,res)=>{
        console.log(req.body)
        res.send("hecho")

}
module.exports = {
    itemsListar,
    itemsGuarda
}