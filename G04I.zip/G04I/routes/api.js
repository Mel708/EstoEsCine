const express = require("express")
const router = express.Router()

router.get("/peliculas", (req,res)=>{
    res.send("Lista de peliculas")
})

router.get("/series", (req,res)=>{
    res.send("Lista de series")
})

module.exports= router