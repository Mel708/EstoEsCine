const express = require("express")
const router =express.Router()
const itemsCtrl= require("../controllers/itemsCtrl")//poner 2 puntos para que pueda buscar en otras carpetas
router.get("/",(req,res)=>{
    res.send(itemsCtrl.itemsListar())
})
router.post("/", itemsCtrl.itemsGuarda)
module.exports =router