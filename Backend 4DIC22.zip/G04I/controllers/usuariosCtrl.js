const usuarioModel = require ('../models/usuarioSchema')
const bcrypt = require ('bcryptjs')
const jwt = require ('jsonwebtoken')

const usuarioGuarda = async (req,res) =>{
    console.log(req.body)
    
    try {
        const usuario = new usuarioModel(req.body)
        usuario.contrasena = await bcrypt.hash(usuario.contrasena,10)
        await usuario.save()
        res.status(200).json({msj : "Usuario Creado"})
                
    } catch (err) {
        res.status(400).json({msj : "error en usuarioGuarda: " + err})
        
    }
}

const usuarioLogin = async (req,res) =>{
    console.log("intento de login")
    console.log(req.body)
    
    const {correo, contrasena} = req.body
    try {
        errores = false
        if(correo == ""){errores = true
            res.status(400).json({'msj':"Correo Incorrecto"})
        }
        if(contrasena == ""){errores = true
            res.status(400).json({'msj':"Contraseña Incorrecta"})
        }
        
        if(!errores){
            //validar
            //usar find en vez de findOne
            let usuario = await usuarioModel.findOne({ 'correo' : correo })
                
                let correcto = false
                console.log(contrasena + " , " + usuario.contrasena)
                correcto = await bcrypt.compare(contrasena, usuario.contrasena)

                if(!correcto){
                    console.log("no encontrado . . .")
                    res.status(400).json( {msj : "no" })
                }else{
                console.log("usuario: " + usuario.nombre)
                //res.status(200).json({ msj: "ok" })

                //generar token
                const payload = {
                    usuario : { id: usuario.id,
                                nombre: usuario.nombre }
                }
                jwt.sign(
                    payload,
                    "palabrasecreta",
                    (error, token) =>{
                        if (error) throw error
                        res.status(200).json({ msj: "ok", "token " : token})
                    }
                )
            }        

        }
    } catch (err) { console.log("error usuarioLogin "+ err) }
}

module.exports={
    usuarioLogin,
    usuarioGuarda
}