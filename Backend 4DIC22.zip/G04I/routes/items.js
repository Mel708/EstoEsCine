const express = require ('express')
const router = express.Router()
const itemsCtrl = require('../controllers/itemsCtrl')
const auth = require('../security/auth')

//Listar
router.get('/', itemsCtrl.itemsListar)

//obtener
router.get('/:id', itemsCtrl.itemObtener)

//Guardar
router.post('/', auth, itemsCtrl.itemsGuarda)

//actualizar
router.put('/', itemsCtrl.itemsActualizar)

//eliminar
router.delete('/:id', itemsCtrl.itemsEliminar)

module.exports = router