export function Header(){
return<>
<h1>Bienvenido a EstoEsCine</h1>
</>
}
export function Menu(){
return <>
<nav className="navbarnavbar-ligh bg-primary">
    <div className="container-fluid">
    <div className="navbar-header">
    <a className="btnbtn-outline-infonavbar-brandmr-0 mr-md-2" to="/" aria-label="Bootstrap">V</a>
    <a className="navbar-brand" href="/">Inicio de sesión</a>
    </div>
    <div className="collapsenavbar-collapse" id="bs-example-navbar-collapse-1"> 
    <ul className="nav navbar-navnavbar-right">
    </ul>
    </div>
    <div className="nav-itemdropdownmy-2 my-sm-0">
    <button className="btnbtn-outline-warning">Login</button>
    </div>
    </div>
    </nav>
    </>
    }
