import { useEffect, useRef } from "react"
import { useParams } from "react-router-dom"
export function GenerosEdit(){
    const refNombre=useRef(null)
    const {id}= useParams()
    console.log(id)
    useEffect(()=>{
        fetch("http://localhost:3000/api/generos/"+id)
        .then(response =>response.json())
        .then(data=>{console.log(data)
        refNombre.current.value=data.nombre
    })
    },[])
    const handleSubmit=()=>{
        console.log("editando genero...")
        const item={
            "id":id,
            "nombre":refNombre.current.value,
        }
        const options={
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(item)
        }
        fetch("http://localhost:3000/api/generos/",options)
        .then(response=> response.json())
        .then(data=>{console.log(data)})
    }
    return <>Estamos editando el genero
    <form>
<div class="form-group"> 
<label for="exampleInputEmail1">
    Nombre del genero
    </label>
    <input type="texto" className="form-control" ref={refNombre}/>
    </div>
    <div class="form-group my-4">
        <button type="button" className="btn btn-primary"onClick={handleSubmit}>
            Guardar</button>
            </div>
        </form></>
}