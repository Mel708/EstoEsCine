const usuarioModel = require('../models/usuarioSchema')
const bcrypt = require ('bcryptjs')
const jwt = require('jsonwebtoken')

const usuarioGuarda = async(req,res)=>{
    console.log(req.body)
    //res.send("...")
try{
        const usuario = new usuarioModel(req.body)
        usuario.contrasena =await bcrypt.hash(usuario.contrasena,10)
        console.log("contraseña generada:"+usuario.contrasena)
        await usuario.save()
        res.status(200).json({msj: "usuario creado"})
    }catch(err){
        res.status(400).json({msj:"error al guardar:" +err })
    }
}
const usuarioLogin = async(req,res)=>{
    console.log("intento de login")
    console.log(req.body)
 const {correo,contrasena}= req.body
try{
        errores = false
        if(correo ==""){errores = true
            res.status(400).json({msj:"correo incorrecto"})
        }
        if (contrasena==""){errores=true
        res.status(400).json({msj: "contraseña incorrecta"})
        }
        if(!errores){//validar
            let usuario= await usuarioModel.findOne({"correo": correo})
            let correcto= false
            console.log(contrasena +"," +usuario.contrasena )
            correcto= await bcrypt.compare(contrasena,usuario.contrasena)
            if(!correcto){
                console.log("No se encuentra el usuario o contraseña correcta")
                res.status(400).json({msj:"datos de acceso son incorrectos"})
            }else{
                console.log ("usuario " + usuario.nombre)
                //res.status(200).json({msj:"bienvenido, datos de acceso validos"})
           // generar un token
           const payload ={
            usuario: {id:usuario.id,
                    nombre: usuario.nombre}
           }
        jwt.sign(
            payload,
            "palabrasecreta",
            (error,token)=>{
                if(error) throw error
                res.status(200).json({msj:"bienvenido, datos de acceso validos", "token":token})
            }
            )
            }
        }
    }catch (err){console.log("error en usuarioLogin"+err)}}
module.exports={
    usuarioLogin,
    usuarioGuarda
}