const express = require ('express')
const router = express.Router()
const actoresCtrl = require('../controllers/actoresCtrl')
const auth = require('../security/auth')

router.get('/',actoresCtrl.actoresListar)
//Obtener
router.get('/:id',actoresCtrl.actoresObtener)

//Guardar
router.post('/',actoresCtrl.actoresGuarda)

//actualizar
router.put('/',actoresCtrl.actoresActualizar)

//eliminar
router.delete('/:id',actoresCtrl.actoresEliminar)

module.exports = router