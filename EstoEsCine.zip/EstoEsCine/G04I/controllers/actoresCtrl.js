const actoresModel = require ('../models/actoresSchema')


const actoresListar = async (req,res) => {
    let actores = await actoresModel.find()
    res.send(actores);
}

//post
const actoresGuarda = (req,res) =>{
    console.log(req.body)
    try {
        const actores = new actoresModel (req.body)
        actores.save()
        res.send("Actores guardados")

    } 
    catch (err) {
        console.log("error actoresGuarda: " + err)
    }
    //res.send("ok")
}


//put
const actoresActualizar = async (req,res) =>{
    console.log(req.body)
    try {
        const {id, nombre} = req.body
        
        if (id == ''){
            res.status(400).send("id de actor No Valido")
        }

        if (nombre == '') {
            res.status(400).send("Nombre de actor No Valido")
        }else {
            //res.send("ok")
            const actor = {}
            actor.nombre=nombre

            const rta = await actoresModel.updateOne(
                { _id : id},
                { $set : actor},
                { new : true}
            )
            res.status(200).json({"msj": "actor Actualizado"})
            
        }
    } 
    catch (err) {
        console.log("Error actoresActualizar: " + err)
    }
}

//delete
const actoresEliminar =  async(req,res) =>{
    const id = req.params.id
    try {
        if (id == '') {
            res.satatus(400).send("el id No es valido")
        }else{
            const rta = await actoresModel.deleteOne({ _id : id})
            res.status(200).send("actor eliminado con exito")
            console.log("eliminadod: " + id)
        }
        
    } catch (err) {
        console.log("error actoresEliminar: " + err)
    }
}
module.exports ={
    actoresListar,
    actoresActualizar,
    actoresEliminar,
    actoresGuarda
}