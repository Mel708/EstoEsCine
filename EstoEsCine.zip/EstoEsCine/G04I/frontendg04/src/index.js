import React from "react";
import ReactDom from "react-dom/client"
import {Pelicula} from "./Pelicula";
import { Header,Menu } from "./components/Header";
//function Mensaje(){// este nombre funcion debe comenzar con mayúscula
 //   const texto = "Películas y series disponibles:"
 //   const asistentes= 580521
 //   return <div>
 //       <h1>Esto Es Cine</h1>
//        <p>App web desarrollada por grupo 1</p>
 //       <p>{texto}{asistentes}</p>
//        </div>
//}
const root= ReactDom.createRoot(document.getElementById("root"))
root.render(<div>
    <Menu/>
    <Header/>
    <Pelicula titulo="Tiburon " 
    duracion={88}
    actores={[{nombre:"Roy Schneider"},{nombre: "Robert Shaw"},{nombre: "Richard Dreyfuss"}]}
    calificacion={8.8}
    violencia={true}
    mas={{edad1:"13", t3d: "Si"}}/>
    <Pelicula titulo="Titanic "
     duracion={180} 
     actores={[{nombre:"Leonardo Dicaprio"},{nombre: "Kate Winslet"}]} 
    calificacion={9.2}
    violencia={true}
    mas={{edad1:"13", t3d: "No"}}
    /></div> 
     )