export function Header(){
return<>
<h1>Bienvenido a EstoEsCine</h1>
</>
}
export function Menu(){
return <>
<select>
    <option>Terror</option>
    <option>Romance</option>
    <option>Ciencia Ficción</option>
</select>
</>
}