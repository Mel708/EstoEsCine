export function Pelicula (props){  
    const titulo="Tiburon"
    const año = 1975
    const genero ="Terror"
    //const actores =[
        //{nombre: "Roy Schneider"},
        //{nombre: "Robert Shaw"},
        //{nombre: "Richard Dreyfuss"},
    //]
    function contar (reparto){
        return <p>actores mencionados:{Object.keys(reparto).length}</p>
    }
    function reparto(actores){
        let text=""
        actores.forEach(element => {
            text += element.nombre +", "
           
        });
        return text
    }
    const etiqueta ={
        display: "block",
        border: "1px solid blue",
        height: "400px",
        width:"340px",padding:"10px"
    }
    return <div style= {etiqueta}>
        <h2>{props.titulo}</h2>
        <h4>{año}</h4>
        <h3>{genero}</h3>
        <h4>{contar(props.actores)}</h4>
        <h4>{reparto(props.actores)}</h4>
        <h4>Duración:{props.duracion}</h4>
        <h4>Calificación:{props.calificacion}</h4>
        <p>Violencia:{props.violencia? "Si":"No"}</p>
        <p style={{color:"red"}}>Edad:{props.mas.edad1} - 3D:{props.mas.t3d}</p>
        </div>
}