import{Link} from "react-router-dom"
export function Header(){
return<>
<h1>Bienvenido a EstoEsCine</h1>
</>
}
export function Menu(){
return <>
<nav className="navbar navbar-ligh bg-primary" >
<div className="container-fluid">
<div className="navbar-header">
<a className="btn btn-outline-info navbar-brand mr-0 mr-md-2" to="/" aria-label="Bootstrap">EstoEsCine</a>
<Link className="navbar-brand" to="/">Inicio</Link>
</div>
<div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">  
<ul className="nav navbar-nav navbar-right">
</ul>
</div>
<div className="nav-item dropdown my-2 my-sm-0">
<Link className="btn btn-outline-warning" to="/login" >Inicio de Sesión</Link>
</div>
</div></nav></>}