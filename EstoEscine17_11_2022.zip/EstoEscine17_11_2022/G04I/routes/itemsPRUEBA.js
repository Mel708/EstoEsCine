const express = require ('express')
const router = express.Router()
const itemsCtrl = require('../controllers/itemsCtrlPRUEBA')

router.get('/', (req,res) => {
    res.send(itemsCtrl.itemsListar())
})

router.post('/', itemsCtrl.itemsGuarda)


module.exports = router