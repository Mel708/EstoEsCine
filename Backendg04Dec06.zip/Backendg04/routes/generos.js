const express = require ('express')
const router = express.Router()
const generosCtrl = require('../controllers/generosCtrl')
const auth = require('../security/auth')

router.get('/',generosCtrl.generoListar)
//Obtener
router.get('/:id',generosCtrl.generoObtener)

//Guardar
router.post('/',auth,generosCtrl.generoGuarda)

//actualizar
router.put('/',generosCtrl.generoActualizar)

//eliminar
router.delete('/:id',auth,generosCtrl.generoEliminar)

module.exports = router