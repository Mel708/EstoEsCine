/*const express = require ('express')
const router = express.Router()
const multer =require ('multer')
const upload =multer ({dest: "public/images"})
const fs =require('node:fs')
const actoresCtrl = require('../controllers/actoresCtrl')
const auth = require('../security/auth')
router.get('/',actoresCtrl.actoresListar)
//Guardar
router.post('/',actoresCtrl.actoresGuarda)
//actualizar
router.put('/',actoresCtrl.actoresActualizar)
router.put('/imagen/:id', upload.single("imagen"), async(req,res)=>{
const imagen=req.file
console.log("se recibe el archivo...")   
console.log(imagen.mimetype)
console.log("el archivo se subió así: "+imagen.filename)
const id=req.params.id
fs.rename('./public/images/' +imagen.filename,'./public/images/'+id+".jpg",()=>{console.log("cambio realizado correctamente")})
res.status(200).json ({"msj":"Imagen ha sido guardada"})
}
)
//eliminar
router.delete('/:id',auth,actoresCtrl.actoresEliminar)
module.exports = router//