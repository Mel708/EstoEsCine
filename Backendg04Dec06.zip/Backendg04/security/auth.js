const jwt = require("jsonwebtoken")
module.exports=async(req,res,next)=>{
    const token = req.header ("x-auth-token")
    if(!token){
        res.status(400).json({msj:"No se encuentra el token"})
    }try{
        const payload=jwt.verify(token,"palabrasecreta")
        req.usuario=payload.nombre
        console.log("se confirma el token ")
        console.log(payload)
        next()
    }catch(err){
        res.status(400).json({msj:"Error, no hay un token"})
    }}