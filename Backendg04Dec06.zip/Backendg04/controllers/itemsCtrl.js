const itemsSchema = require('../models/itemsSchema');
const itemsModel = require ('../models/itemsSchema')

const itemsListar = async (req,res) =>{
    const items = await itemsModel.find()
    res.send(items);
 
}
const itemObtener = async(req,res) =>{
    const id = req.params.id
    console.log(id)
    try{
        const c = await itemsModel.findOne({_id:id})
        res.status(200).json(c)
    }catch(error){
        if(error){
            console.log("Error itemObtener " + error)
            res.status(400).json("Error itemObtener")
        }
    }
}

//Guardar ITEMS
const itemsGuarda = (req,res) =>{
    console.log(req.body)
    try {
        const item = new itemsModel (req.body)
        item.save()
        res.send("item guardado")

    } 
    catch (err) {
        console.log("error itemsGuarda: " + err)
    }
    //res.send("ok")
}

////////put
const itemsActualizar = async (req,res) =>{
    console.log(req.body)
    try {
        const {id, titulo,tipo, duracion, genero, ano, actores,imagen} = req.body
        
        if (id == ''){
            res.status(400).send("id de Item No Valido")
        }

        if (titulo == '') {
            res.status(400).send("Titulo de item No Valido")
        }else {
            //res.send("ok")
            const item = {}
            item.titulo = titulo
            item.tipo=tipo
            item.duracion = duracion
            item.genero = genero
            item.ano = ano
            item.actores = actores
            item.imagen= imagen

            const rta = await itemsModel.updateOne(
                { _id : id},
                { $set : item},
                { new : true}
            )
            res.status(200).json({"msj": "Item Actualizado"})
            
        }
    } 
    catch (err) {
        console.log("Error itemsActualizar: " + err)
    }
}

//delete
const itemsEliminar =  async(req,res) =>{
    const id = req.params.id
    try {
        if (id == '') {
            res.satatus(400).send("el id No es valido")
        }else{
            const rta = await itemsModel.deleteOne({ _id : id})
            res.status(200).send("item Eliminado con exito")
            console.log("eliminado: " + id)
        }
        
    } catch (err) {
        console.log("error itemsEliminar: " + err)
    }
    //console.log(id)
    //res.send("eliminando...")
}


module.exports ={
    itemsListar,
    itemsGuarda,
    itemsActualizar,
    itemsEliminar,
    itemObtener
}