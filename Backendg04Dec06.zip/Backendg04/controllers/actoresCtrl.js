const actoresModel = require ('../models/actoresSchema')

const actoresListar = async (req,res) =>{
    const actores = await actoresModel.find()
    console.log(actores)
    res.send(actores);

}
//obtener
const actoresObtener = async(req,res) =>{
    const id = req.params.id
    console.log(id)
    try{
        const c = await actoresModel.findOne({_id:id})
        res.status(200).json(c)
    }catch(error){
        if(error){
            console.log("Error actoresObtener " + error)
            res.status(400).json("Error actoresObtener")
        }
    }
}

//post
const actoresGuarda = (req,res) =>{
    console.log(req.body)
    try {
        const actor = new actoresModel (req.body)
        actor.save()
        res.send("Actores guardados")

    } 
    catch (err) {
        console.log("error actoresGuarda: " + err)
    }
    //res.send("ok")
}


//put
const actoresActualizar = async (req,res) =>{
    console.log(req.body)
    try {
        const {id, nombre,imagen} = req.body
        
        if (id == ''){
            res.status(400).send("id de actor No Valido")
        }

        if (nombre == '') {
            res.status(400).send("Nombre de actor No Valido")
        }else {
            //res.send("ok")
            const actor = {}
            actor.nombre= nombre
            actor.imagen= imagen

            const rta = await actoresModel.updateOne(
                { _id : id},
                { $set : actor},
                { new : true}
            )
            res.status(200).json({"msj": "actor Actualizado"})
            
        }
    } 
    catch (err) {
        console.log("Error actoresActualizar: " + err)
    }
}

//delete
const actoresEliminar =  async(req,res) =>{
    const id = req.params.id
    try {
        if (id == '') {
            res.status(400).send("el id No es valido")
        }else{
            const rta = await actoresModel.deleteOne({ _id : id})
            res.status(200).send("actor eliminado con exito")
            console.log("eliminado: " + id)
        }
        
    } catch (err) {
        console.log("error actoresEliminar: " + err)
    }
}
module.exports ={
    actoresListar,
    actoresActualizar,
    actoresEliminar,
    actoresGuarda,
    actoresObtener
}