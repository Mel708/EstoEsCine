import { useEffect, useState } from "react"
import { Link } from "react-router-dom"

export function GenerosList(){
    const [generos, setGeneros] = useState([])
    
    useEffect(() => {
        fetch("http://localhost:3000/api/generos")
        .then(response => response.json())
        .then(data => { console.log(data)
            setGeneros(data)})
    }, [])

    return<> 
        <table className="table">
            <tr>
                <th>Nombre</th>
                <th>Acciones</th>               
            </tr>
            { generos.map(dato =>(
                <tr>
                    <td>{dato.nombre}</td>
                    <td><Link to={`/tablero/generosEdit/${dato._id}`}>Editar</Link></td>
                </tr>                    
            ))}
        </table>
    </>
}