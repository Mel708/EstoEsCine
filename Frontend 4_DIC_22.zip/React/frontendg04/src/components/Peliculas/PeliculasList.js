import { useEffect, useState } from "react"
import { Link } from "react-router-dom"

export function PeliculasList(){
    const [items, setItems] = useState([])

    useEffect(() => {
        fetch ("http://localhost:3000/api/items")
        .then(response => response.json())
        .then(data => {console.log(data)
            setItems(data)})
    }, [])
    return <>
        <table className="table">
            <tr>
                <th>Titulo</th>
                <th>Genero</th>
                <th>Opciones</th>
            </tr>
            { items.map(dato => (
                <tr>
                    <td>{ dato.titulo }</td>
                    <td>{ dato.genero }</td>
                    <td><Link to={`/tablero/peliculasEdit/${dato._id}`}>Editar</Link></td>
                </tr>
            )) }

        </table>
    
    </>
}