import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { Routes, Route, Link } from "react-router-dom"

import { GenerosList } from "../Generos/GenerosList"
import { GenerosEdit } from "../Generos/GenerosEdit" 
import { PeliculasList } from "../Peliculas/PeliculasList"
import { PeliculasEdit } from "../Peliculas/PeliculasEdit"
import { ActoresList } from "../Actores/ActoresList"
import { ActoresEdit } from "../Actores/ActoresEdit"
import { ActoresCreate } from "../Actores/ActoresCreate"

export function Tablero(){
    
    const navigate = useNavigate()
    useEffect(()=>{
        try {
            const token = localStorage.getItem("token")
                            
                if(!token)
                    navigate("/")
                else
                console.log ("token: " + token)

        } catch (error) {
            console.log("Error de Seguridad")
            navigate("/")
        }

    },[])

    function handleCerrar(){
        localStorage.removeItem("token")
        navigate("/login")
    }

    return <><h1>Panel de Administración</h1>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <div className="row">
            <div className="col-3">
                <h5>Opciones</h5>
                <ul>
                    <li><Link to="/tablero/generosList">Generos</Link></li>
                    <li><Link to="/tablero/peliculasList">Peliculas</Link></li>
                    <li><Link to="/tablero/actoresList">Actores</Link></li>
                </ul>
            </div>
            <div className="col-9">
                <Routes>
                    <Route path="/generosList" element={ <GenerosList/> }></Route>
                    <Route path="/generosEdit/:id" element={ <GenerosEdit/> }></Route>
                    <Route path="/peliculasList" element={ <PeliculasList/> }></Route>
                    <Route path="/peliculasEdit/:id" element={ <PeliculasEdit/> }></Route>
                    <Route path="/actoresList" element={ <ActoresList/> }></Route>
                    <Route path="/actoresEdit/:id" element={ <ActoresEdit/> }></Route>
                    <Route path="/actoresCreate" element={ <ActoresCreate/> }></Route>
                </Routes>
            </div>
        </div>
        
       {/* nav-item dropdown my-2 mysm-0 */}
        
        <div className="d-grid gap-2 d-md-flex justify-content-md-end">
        <button type="button" className="btn btn-danger me-md-2" onClick={handleCerrar} >Cerrar</button>
        </div>
    </>
        
    
}