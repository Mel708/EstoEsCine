import { useEffect, useRef } from "react"
import { useParams } from "react-router-dom"

export function ActoresEdit(){

    const refNombre = useRef(null)
        
    const {id} = useParams()
    console.log(id)

    useEffect(()=>{
        fetch("http://localhost:3000/api/actores/" + id)
        .then(response => response.json())
        .then(data => { console.log(data)
            refNombre.current.value = data.nombre         
        })
    },[])

    const handleSubmit = ()=>{
        console.log("Editando . . . .")
        const item = {
            "id" : id,
            "nombre" : refNombre.current.value
        }

        const options = {
            method : "PUT",
            headers : {
                "Content-Type" : "application/json"
            },
            body: JSON.stringify(item)
        }
        fetch("http://localhost:3000/api/actores/", options)
        .then(response => response.json())
        .then(data => { console.log(data) })
    }

    return<>
        <form>
            <div className="form-group">
                <label for="nombreActor">
                    Nombre
                </label>
                <input type="texto" className="form-control" ref={refNombre}/>
            </div>
            <div className="form-group my-4">
                <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                    Guardar
                </button>
            </div>
        </form>
    </>
}