import { useEffect, useState } from "react"
import { Link } from "react-router-dom"

export function ActoresList(){
    const [actores, setActores] = useState([])
    
    useEffect(() => {
        fetch("http://localhost:3000/api/actores")
        .then(response => response.json())
        .then(data => { console.log(data)
            setActores(data)})
    }, [])

    return<> 
        <table className="table">
            <tr>
                <th>Nombre</th>
                <th>Acciones</th>    
                <th><Link to={`/tablero/actoresCreate/`}>Crear Nuevo Actor</Link></th>           
            </tr>
            <tr>
            
            </tr>
            { actores.map(dato =>(
                <tr>
                    <td>{dato.nombre}</td>
                    <td><Link to={`/tablero/actoresEdit/${dato._id}`}>Editar</Link></td>
                </tr>                    
            ))}
            
        </table>
    </>
}