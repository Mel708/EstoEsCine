const express = require ('express')
const router = express.Router()
const itemsCtrl = require('../controllers/itemsCtrl')

router.get('/', itemsCtrl.itemsListar)

//Guardar
router.post('/', itemsCtrl.itemsGuarda)

//actualizar
router.put('/', itemsCtrl.itemsActualizar)

//eliminar
router.delete('/:id', itemsCtrl.itemsEliminar)

module.exports = router