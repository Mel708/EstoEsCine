import swal from "sweetalert"
import { useRef } from "react"
import{useNavigate} from "react-router-dom"
export function Login (){
    const navigate= useNavigate()
    const correoRef=useRef()
    const contrasenaRef=useRef()
    const handleChange =(ev)=>{console.log(ev.target.value)}
    const handleSubmit=(ev)=>{
        ev.preventDefault()

        console.log("enviando datos...")
        const correo = correoRef.current.value
        console.log("correo..."+ correo)
        const contrasena= contrasenaRef.current.value
        const usuario={
            "correo": correo,
            "contrasena": contrasena
        }
        const options= {
            method: "POST",
            body: JSON.stringify(usuario),
            headers:{
                "Content-Type": "application/json"
            }
        }
        fetch("http://localhost:3000/api/usuarios/login",options)
        .then(response=> response.json())
        .then(data=> {console.log(data)
            if(data.msj =="bienvenido, datos de acceso validos"){
                navigate("/tablero")  
                localStorage.setItem("token",data.token)
                const token =localStorage.getItem("token")
                console.log("token"+ token)
            }else{
                swal("Los datos de acceso son incorrectos")

            }})
        .catch(err=>{console.log(err)})
        //if(correo === "admin@correo.com")
        //swal({
           // title:"Acceso",
           // text:"Acceso concedido",
           // icon:"success"
    
        //else
            //swal("Datos de acceso son incorrectos")
    }
return <div class="container-fluid">
<div class="row">
<div class="col-md-4 offset -4">
<form onSubmit={handleSubmit}>
    <div class="form-group">
    <label for="exampleInputEmail1">
        Correo electrónico
    </label>
    <input type="email" ref={correoRef} class="form-control" id="exampleInputEmail1" onClick= {function(){console.log('email click!')}}onChange={handleChange}/>  
    </div>
    <div class="form-group">
    <label for="exampleInputPassword1">
        Contraseña
    </label>
    <input type="password" ref={contrasenaRef}class="form-control" id="exampleInputPassword1"/>  
    </div>
    <div class="form-group my-4">
        <button type="button" class="btn btn-primary" onClick= {handleSubmit}>
            Entrar</button>
    </div>
    </form>
</div>
</div>
</div> 
}