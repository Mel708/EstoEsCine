import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { Routes,Link,Route } from "react-router-dom"
import { GenerosList } from "../Generos/GenerosList"
import { PeliculasList } from "../Peliculas/PeliculasList"
import { PeliculasEdit } from "../Peliculas/PeliculasEdit"
import { PeliculasGuardar } from "../Peliculas/PeliculasGuardar"
import { GenerosEdit } from "../Generos/GenerosEdit"
import { ActoresList } from "../Actores/ActoresList"
import { ActoresEdit } from "../Actores/ActoresEdit"
export function Tablero(){
    //const token = localStorage.getItem("token")
    //console.log(token)
    const navigate=useNavigate()
    useEffect(()=>{
        try{
        const token= localStorage.getItem("token")
        if(!token)
        navigate("/")
        else
        console.log("token " + token)
        }catch(error){
            console.log("Error de seguridad")
            navigate("/")
        }
    },[])
    const handleCerrar=()=>{
       localStorage.removeItem("token")
       navigate("/login")
    }
    return <><h1>Tablero de control</h1>
    <div className="row">
        <div className= 'col-3'>
        Opciones
        <ul>
            <li><Link to="/tablero/generosList">Generos</Link></li>
            <li><Link to="/tablero/peliculasList">Peliculas</Link></li>
            <li><Link to="/tablero/actoresList">Actores</Link></li>
            <li><Link to="/tablero/PeliculasGuardar">Añadir Pelicula</Link></li>
            </ul>
        </div>
        <div className= 'col-9'>
        <Routes>
        <Route path="/generosList" element={<GenerosList/>}></Route>
        <Route path="/peliculasList" element={<PeliculasList/>}></Route>
        <Route path="/PeliculasEdit/:id" element={<PeliculasEdit/>}></Route>
        <Route path="/PeliculasGuardar/" element={<PeliculasGuardar/>}></Route>
        <Route path="/GenerosEdit/:id" element={<GenerosEdit/>}></Route>
        <Route path="/ActoresList" element={<ActoresList/>}></Route>
        <Route path="/ActoresEdit/:id" element={<ActoresEdit/>}></Route>
        </Routes>
        </div>
    </div>
     <button onClick={handleCerrar}>Cerrar Sesión</button>    
</>}