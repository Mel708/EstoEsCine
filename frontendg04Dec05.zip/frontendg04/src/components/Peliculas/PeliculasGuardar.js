import { useEffect, useRef, useState } from "react"
import { useParams } from "react-router-dom"
export function PeliculasGuardar(){
    const refTitulo=useRef("")
    const refImagen=useRef("")
    const refGenero=useRef("")
    //const refTipo=useRef(null)
    const refDuracion=useRef("")
   // const refCreatedAt=useRef(null)
    //const refCreadoPor=useRef(null)
    const refActores=useRef("")
    const refAno=useRef("")
    const {id}= useParams()
    console.log(id)
    useEffect(()=>{
        fetch("http://localhost:3000/api/items")
        .then(response =>response.json())
        .then(data=>{console.log(data)
        refTitulo.current.value=data.titulo
        //refTipo.current.value=null
        refDuracion.current.value=data.duracion
        refGenero.current.value=data.genero
        refAno.current.value=data.ano
        refActores.current.value=data.actores
        refImagen.current.value=data.imagen
        
        
        //refCreatedAt.current.value=null
        //refCreadoPor.current.value=null 
        
    })
    },[])
    const handleSubmit=()=>{
        console.log("creando...")
        const item={
            "id":id,
            "titulo":refTitulo.current.value,
            "duracion":refDuracion.current.value,
            "genero":refGenero.current.value,
            "Año":refAno.current.value,
            "Actores":refActores.current.value,
            "imagen":refImagen.current.value
           
        }
        const options={
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(item),
        }
        fetch("http://localhost:3000/api/items",options)
        .then(response=> response.json())
        .then(data=>{console.log(data)})
    }
    return <>Estamos guardando la pelicula
    <form>
<div class="form-group"> 
<label for="exampleInputEmail1">
    Nombre de la Pelicula
    </label>
    <input type="texto" className="form-control" ref={refTitulo}/>
    </div>
    <div class="form-group"> 
<label for="exampleInputEmail1">
    Duración en minutos
    </label>
    <input type="texto" className="form-control" ref={refTitulo}/>
    </div>
    <div class="form-group"> 
<label for="exampleInputEmail1">
    Genero
    </label>
    <input type="texto" className="form-control" ref={refTitulo}/>
    </div>
    <div class="form-group"> 
<label for="exampleInputEmail1">
    Año
    </label>
    <input type="texto" className="form-control" ref={refTitulo}/>
    </div>
    <div class="form-group"> 
<label for="exampleInputEmail1">
    actores
    </label>
    <input type="texto" className="form-control" ref={refTitulo}/>
    </div>
    <div class="form-group"> 
<label for="exampleInputEmail1">
    Imagen
    </label>
    <input type="texto" className="form-control"ref={refImagen} />
    <div class="form-group my-4">
        <button type="button" className="btn btn-primary"onClick={handleSubmit}>
            Guardar</button>
            </div></div>
        </form></>
}