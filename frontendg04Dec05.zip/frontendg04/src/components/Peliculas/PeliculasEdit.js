import { useEffect, useRef } from "react"
import { useParams } from "react-router-dom"
export function PeliculasEdit(){
    const refTitulo=useRef(null)
    const refImagen=useRef(null)
    const {id}= useParams()
    console.log(id)
    useEffect(()=>{
        fetch("http://localhost:3000/api/items/"+id)
        .then(response =>response.json())
        .then(data=>{console.log(data)
        refTitulo.current.value=data.titulo
        refImagen.current.value=data.imagen
    })
    },[])
    const handleSubmit=()=>{
        console.log("editando...")
        const item={
            "id":id,
            "titulo":refTitulo.current.value,
            "imagen":refImagen.current.value,
        }
        const options={
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(item)
        }
        fetch("http://localhost:3000/api/items/",options)
        .then(response=> response.json())
        .then(data=>{console.log(data)})
    }
    return <>Estamos editando la pelicula
    <form>
<div class="form-group"> 
<label for="exampleInputEmail1">
    Nombre de la Pelicula
    </label>
    <input type="texto" className="form-control" ref={refTitulo}/>
    </div>
    <div class="form-group"> 
<label for="exampleInputEmail1">
    Imagen
    </label>
    <input type="texto" className="form-control"ref={refImagen} />
    </div>
    <div class="form-group my-4">
        <button type="button" className="btn btn-primary"onClick={handleSubmit}>
            Guardar</button>
            </div>
        </form></>
}