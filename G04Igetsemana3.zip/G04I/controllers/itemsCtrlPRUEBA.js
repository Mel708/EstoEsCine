const itemsListar = () =>{
    let listado ={
        "1" : "terminator",
        "2" : "Indiana Jones",
        "3" : "Titanic",
        "4" : "Encanto"
    }
    return listado
}

const itemsGuarda = (req,res) =>{
    console.log(req.body)
    res.send("ok")
}

module.exports = {
    itemsListar,
    itemsGuarda
}