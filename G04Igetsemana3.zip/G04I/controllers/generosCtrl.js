const generoModel = require ('../models/generosSchema')


const generoListar = async (req,res) => {
    let generos = await generoModel.find()
    res.send(generos);
}
module.exports ={
    generoListar
}