const itemsModel = require ('../models/itemsSchema')


const itemsListar = async (req,res) => {
    let items = await itemsModel.find()
    res.send(items);
}
module.exports ={
    itemsListar
}