const mongoose = require ('mongoose')

const itemsSchema = mongoose.Schema(
    {
        nombre:{
            type : String,
            require : true,
            trim : true
        }
    }
)

module.exports = mongoose.model("items", itemsSchema)