const express = require ('express')
const router = express.Router()
const itemsCtrl = require('../controllers/itemsCtrl')

router.get('/', itemsCtrl.itemsListar)

module.exports = router