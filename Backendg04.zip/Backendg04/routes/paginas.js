const express = require('express')
const router = express.Router()

router.get('/', (req,res) =>{
    res.send('pagina aceca de...')
})

module.exports = router