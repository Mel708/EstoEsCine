const generoModel = require ('../models/generosSchema')


const generoListar = async (req,res) => {
    let generos = await generoModel.find()
    res.send(generos);
}

//post
const generoGuarda = (req,res) =>{
    console.log(req.body)
    try {
        const genero = new generoModel (req.body)
        genero.save()
        res.send("Genero guardado")

    } 
    catch (err) {
        console.log("error GeneroGuarda: " + err)
    }
    //res.send("ok")
}

//put
const generoActualizar = async (req,res) =>{
    console.log(req.body)
    try {
        const {id, nombre} = req.body
        
        if (id == ''){
            res.status(400).send("id de genero No Valido")
        }

        if (nombre == '') {
            res.status(400).send("Titulo de genero No Valido")
        }else {
            //res.send("ok")
            const genero = {}
            genero.nombre = nombre

            const rta = await generoModel.updateOne(
                { _id : id},
                { $set : genero},
                { new : true}
            )
            res.status(200).json({"msj": "Genero Actualizado"})
            
        }
    } 
    catch (err) {
        console.log("Error generosActualizar: " + err)
    }
}

//delete
const generoEliminar =  async(req,res) =>{
    const id = req.params.id
    try {
        if (id == '') {
            res.status(400).send("el id No es valido")
        }else{
            const rta = await generoModel.deleteOne({ _id : id})
            res.status(200).send("Genero eliminado con exito")
            console.log("eliminado: " + id)
        }
        
    } catch (err) {
        console.log("error generosEliminar: " + err)
    }
}

module.exports ={
    generoListar,
    generoActualizar,
    generoEliminar,
    generoGuarda
}